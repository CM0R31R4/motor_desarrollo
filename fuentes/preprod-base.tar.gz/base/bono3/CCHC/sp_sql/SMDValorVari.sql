locale is "es_ES.UTF-8"
locale charset is "UTF-8"
locale is "es_ES.UTF-8"
locale charset is "UTF-8"
1> 2> Name	Owner	Type	Created_datetime
SMDValorVari	dbo	stored procedure	abr 05 2012 08:51
(1 row affected)
Parameter_name	Type	Length	Prec	Scale	Param_order	Collation
@extCodFinanciador	int	4	10	0	1	NULL
@extHomNumeroConvenio	char	15	15	NULL	2	SQL_Latin1_General_CP1_CI_AS
@extHomLugarConvenio	char	10	10	NULL	3	SQL_Latin1_General_CP1_CI_AS
@extSucVenta	char	10	10	NULL	4	SQL_Latin1_General_CP1_CI_AS
@extRutConvenio	char	12	12	NULL	5	SQL_Latin1_General_CP1_CI_AS
@extRutTratante	char	12	12	NULL	6	SQL_Latin1_General_CP1_CI_AS
@extEspecialidad	char	10	10	NULL	7	SQL_Latin1_General_CP1_CI_AS
@extRutSolicitante	char	12	12	NULL	8	SQL_Latin1_General_CP1_CI_AS
@extRutBeneficiario	char	12	12	NULL	9	SQL_Latin1_General_CP1_CI_AS
@extTratamiento	char	1	1	NULL	10	SQL_Latin1_General_CP1_CI_AS
@extCodigoDiagnostico	char	10	10	NULL	11	SQL_Latin1_General_CP1_CI_AS
@extNivelConvenio	tinyint	1	3	0	12	NULL
@extUrgencia	char	1	1	NULL	13	SQL_Latin1_General_CP1_CI_AS
@extLista1	char	255	255	NULL	14	SQL_Latin1_General_CP1_CI_AS
@extLista2	char	255	255	NULL	15	SQL_Latin1_General_CP1_CI_AS
@extLista3	char	255	255	NULL	16	SQL_Latin1_General_CP1_CI_AS
@extLista4	char	255	255	NULL	17	SQL_Latin1_General_CP1_CI_AS
@extLista5	char	255	255	NULL	18	SQL_Latin1_General_CP1_CI_AS
@extLista6	char	255	255	NULL	19	SQL_Latin1_General_CP1_CI_AS
@extLista7	char	255	255	NULL	20	SQL_Latin1_General_CP1_CI_AS
@extNumPrestaciones	tinyint	1	3	0	21	NULL
@extCodError	char	1	1	NULL	22	SQL_Latin1_General_CP1_CI_AS
@extMensajeError	char	30	30	NULL	23	SQL_Latin1_General_CP1_CI_AS
@extPlan	char	15	15	NULL	24	SQL_Latin1_General_CP1_CI_AS
@extGlosa1	char	50	50	NULL	25	SQL_Latin1_General_CP1_CI_AS
@extGlosa2	char	50	50	NULL	26	SQL_Latin1_General_CP1_CI_AS
@extGlosa3	char	50	50	NULL	27	SQL_Latin1_General_CP1_CI_AS
@extGlosa4	char	50	50	NULL	28	SQL_Latin1_General_CP1_CI_AS
@extGlosa5	char	50	50	NULL	29	SQL_Latin1_General_CP1_CI_AS
(29 rows affected)
(return status = 0)
1> 