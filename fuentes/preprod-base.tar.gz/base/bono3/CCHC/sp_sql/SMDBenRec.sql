locale is "es_ES.UTF-8"
locale charset is "UTF-8"
locale is "es_ES.UTF-8"
locale charset is "UTF-8"
1> 2> Name	Owner	Type	Created_datetime
SMDBenRec	dbo	stored procedure	abr 05 2012 08:51
(1 row affected)
Parameter_name	Type	Length	Prec	Scale	Param_order	Collation
@extCodFinanciador	int	4	10	0	1	NULL
@extRutCotizante	char	12	12	NULL	2	SQL_Latin1_General_CP1_CI_AS
@extCorrBenef	int	4	10	0	3	NULL
@extRutBeneficiario	char	12	12	NULL	4	SQL_Latin1_General_CP1_CI_AS
@extCodResBen	char	1	1	NULL	5	SQL_Latin1_General_CP1_CI_AS
@extMensajeError	char	30	30	NULL	6	SQL_Latin1_General_CP1_CI_AS
(6 rows affected)
(return status = 0)
1> 