locale is "es_ES.UTF-8"
locale charset is "UTF-8"
locale is "es_ES.UTF-8"
locale charset is "UTF-8"
1> 2> Name	Owner	Type	Created_datetime
SMDSolicFolios	dbo	stored procedure	abr 05 2012 08:51
(1 row affected)
Parameter_name	Type	Length	Prec	Scale	Param_order	Collation
@extCodFinanciador	int	4	10	0	1	NULL
@extNumFolios	tinyint	1	3	0	2	NULL
@extCodError	char	1	1	NULL	3	SQL_Latin1_General_CP1_CI_AS
@extMensajeError	char	30	30	NULL	4	SQL_Latin1_General_CP1_CI_AS
(4 rows affected)
(return status = 0)
1> 