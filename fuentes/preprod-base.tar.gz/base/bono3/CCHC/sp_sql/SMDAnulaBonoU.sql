locale is "es_ES.UTF-8"
locale charset is "UTF-8"
locale is "es_ES.UTF-8"
locale charset is "UTF-8"
1> 2> Name	Owner	Type	Created_datetime
SMDAnulaBonoU	dbo	stored procedure	abr 05 2012 08:51
(1 row affected)
Parameter_name	Type	Length	Prec	Scale	Param_order	Collation
@extCodFinanciador	smallint	2	5	0	1	NULL
@extFolioBono	float	8	53	NULL	2	NULL
@extIndTratam	char	1	1	NULL	3	SQL_Latin1_General_CP1_CI_AS
@extFecTratam	char	8	8	NULL	4	SQL_Latin1_General_CP1_CI_AS
@extCodError	char	1	1	NULL	5	SQL_Latin1_General_CP1_CI_AS
@extMensajeError	char	30	30	NULL	6	SQL_Latin1_General_CP1_CI_AS
(6 rows affected)
(return status = 0)
1> 