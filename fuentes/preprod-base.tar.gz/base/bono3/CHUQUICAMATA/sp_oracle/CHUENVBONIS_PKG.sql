
SQL*Plus: Release 11.2.0.3.0 Production on Thu Aug 8 19:33:22 2013

Copyright (c) 1982, 2011, Oracle.  All rights reserved.


Connected to:
Oracle Database 10g Release 10.2.0.4.0 - Production

SQL> SQL> ERROR:
ORA-04043: object CHUENVBONIS_PKG does not exist


SQL> Disconnected from Oracle Database 10g Release 10.2.0.4.0 - Production
