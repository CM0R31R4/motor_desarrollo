
SQL*Plus: Release 11.2.0.3.0 Production on Tue Aug 19 12:09:37 2014

Copyright (c) 1982, 2011, Oracle.  All rights reserved.


Connected to:
Oracle Database 10g Release 10.2.0.4.0 - 64bit Production

SQL> SQL> PROCEDURE FNDANULABONOU
 Argument Name			Type			In/Out Default?
 ------------------------------ ----------------------- ------ --------
 SRV_MESSAGE			VARCHAR2		IN/OUT
 IN_EXTCODFINANCIADOR		NUMBER			IN
 IN_EXTFOLIOBONO		NUMBER			IN
 IN_EXTINDTRATAM		VARCHAR2		IN
 IN_EXTFECTRATAM		DATE			IN
 OUT_EXTCODERROR		VARCHAR2		OUT
 OUT_EXTMENSAJEERROR		VARCHAR2		OUT

SQL> 
no rows selected

SQL> Disconnected from Oracle Database 10g Release 10.2.0.4.0 - 64bit Production
