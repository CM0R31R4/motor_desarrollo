
SQL*Plus: Release 11.2.0.3.0 Production on Tue Aug 19 12:09:40 2014

Copyright (c) 1982, 2011, Oracle.  All rights reserved.


Connected to:
Oracle Database 10g Release 10.2.0.4.0 - 64bit Production

SQL> SQL> PROCEDURE FNDENROLA
 Argument Name			Type			In/Out Default?
 ------------------------------ ----------------------- ------ --------
 SRV_MESSAGE			VARCHAR2		IN/OUT
 IN_EXTCODFINANCIADOR		NUMBER			IN
 IN_EXTRUTENROLAR		VARCHAR2		IN
 IN_EXTRUTBENEFICIARIO		VARCHAR2		IN
 OUT_EXTVALIDO			VARCHAR2		OUT
 OUT_EXTNOMBRECOMP		VARCHAR2		OUT

SQL> 
no rows selected

SQL> Disconnected from Oracle Database 10g Release 10.2.0.4.0 - 64bit Production
