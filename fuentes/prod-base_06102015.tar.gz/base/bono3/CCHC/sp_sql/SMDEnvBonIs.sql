locale is "es_ES.UTF-8"
locale charset is "UTF-8"
locale is "es_ES.UTF-8"
locale charset is "UTF-8"
1> 2> Name	Owner	Type	Created_datetime
SMDEnvBonIs	dbo	stored procedure	abr 05 2012 08:51
(1 row affected)
Parameter_name	Type	Length	Prec	Scale	Param_order	Collation
@extCodFinanciador	smallint	2	5	0	1	NULL
@extHomNumeroConvenio	char	15	15	NULL	2	SQL_Latin1_General_CP1_CI_AS
@extHomLugarConvenio	char	10	10	NULL	3	SQL_Latin1_General_CP1_CI_AS
@extSucVenta	char	10	10	NULL	4	SQL_Latin1_General_CP1_CI_AS
@extRutConvenio	char	12	12	NULL	5	SQL_Latin1_General_CP1_CI_AS
@extRutAsociado	char	12	12	NULL	6	SQL_Latin1_General_CP1_CI_AS
@extNomPrestador	char	40	40	NULL	7	SQL_Latin1_General_CP1_CI_AS
@extRutTratante	char	12	12	NULL	8	SQL_Latin1_General_CP1_CI_AS
@extEspecialidad	char	10	10	NULL	9	SQL_Latin1_General_CP1_CI_AS
@extRutBeneficiario	char	12	12	NULL	10	SQL_Latin1_General_CP1_CI_AS
@extRutCotizante	char	12	12	NULL	11	SQL_Latin1_General_CP1_CI_AS
@extRutAcompanante	char	12	12	NULL	12	SQL_Latin1_General_CP1_CI_AS
@extRutEmisor	char	12	12	NULL	13	SQL_Latin1_General_CP1_CI_AS
@extRutCajero	char	12	12	NULL	14	SQL_Latin1_General_CP1_CI_AS
@extCodigoDiagnostico	char	10	10	NULL	15	SQL_Latin1_General_CP1_CI_AS
@extDescuentoxPlanilla	char	1	1	NULL	16	SQL_Latin1_General_CP1_CI_AS
@extMontoExcedente	float	8	53	NULL	17	NULL
@extFechaEmision	char	8	8	NULL	18	SQL_Latin1_General_CP1_CI_AS
@extNivelConvenio	tinyint	1	3	0	19	NULL
@extFolioFinanciador	float	8	53	NULL	20	NULL
@extMontoValorTotal	float	8	53	NULL	21	NULL
@extMontoAporteTotal	float	8	53	NULL	22	NULL
@extMontoCopagoTotal	float	8	53	NULL	23	NULL
@extNumOperacion	float	8	53	NULL	24	NULL
@extCorrPrestacion	float	8	53	NULL	25	NULL
@extTipoSolicitud	tinyint	1	3	0	26	NULL
@extFechaInicio	char	8	8	NULL	27	SQL_Latin1_General_CP1_CI_AS
@extUrgencia	char	1	1	NULL	28	SQL_Latin1_General_CP1_CI_AS
@extPlan	char	15	15	NULL	29	SQL_Latin1_General_CP1_CI_AS
@extLista1	char	255	255	NULL	30	SQL_Latin1_General_CP1_CI_AS
@extLista2	char	255	255	NULL	31	SQL_Latin1_General_CP1_CI_AS
@extLista3	char	255	255	NULL	32	SQL_Latin1_General_CP1_CI_AS
@extCodError	char	1	1	NULL	33	SQL_Latin1_General_CP1_CI_AS
@extMensajeError	char	30	30	NULL	34	SQL_Latin1_General_CP1_CI_AS
(34 rows affected)
(return status = 0)
1> 