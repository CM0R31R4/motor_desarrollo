locale is "es_ES.UTF-8"
locale charset is "UTF-8"
locale is "es_ES.UTF-8"
locale charset is "UTF-8"
1> 2> Name	Owner	Type	Created_datetime
SMDValTrans	dbo	stored procedure	abr 05 2012 08:51
(1 row affected)
Parameter_name	Type	Length	Prec	Scale	Param_order	Collation
@extCodFinanciador	int	4	10	0	1	NULL
@extFolioFinanciador	float	8	53	NULL	2	NULL
@extAccion	char	1	1	NULL	3	SQL_Latin1_General_CP1_CI_AS
@extPregunta	char	1	1	NULL	4	SQL_Latin1_General_CP1_CI_AS
@extRespuesta	char	1	1	NULL	5	SQL_Latin1_General_CP1_CI_AS
@extCodError	char	1	1	NULL	6	SQL_Latin1_General_CP1_CI_AS
@extMensajeError	char	30	30	NULL	7	SQL_Latin1_General_CP1_CI_AS
(7 rows affected)
(return status = 0)
1> 