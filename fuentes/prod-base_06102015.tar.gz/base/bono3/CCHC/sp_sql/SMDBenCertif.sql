locale is "es_ES.UTF-8"
locale charset is "UTF-8"
locale is "es_ES.UTF-8"
locale charset is "UTF-8"
1> 2> Name	Owner	Type	Created_datetime
SMDBenCertif	dbo	stored procedure	abr 05 2012 08:51
(1 row affected)
Parameter_name	Type	Length	Prec	Scale	Param_order	Collation
@extCodFinanciador	smallint	2	5	0	1	NULL
@extRutBeneficiario	char	12	12	NULL	2	SQL_Latin1_General_CP1_CI_AS
@extFechaActual	char	8	8	NULL	3	SQL_Latin1_General_CP1_CI_AS
@extApellidoPat	char	30	30	NULL	4	SQL_Latin1_General_CP1_CI_AS
@extApellidoMat	char	30	30	NULL	5	SQL_Latin1_General_CP1_CI_AS
@extNombres	char	40	40	NULL	6	SQL_Latin1_General_CP1_CI_AS
@extSexo	char	1	1	NULL	7	SQL_Latin1_General_CP1_CI_AS
@extFechaNacimi	char	8	8	NULL	8	SQL_Latin1_General_CP1_CI_AS
@extCodEstBen	char	1	1	NULL	9	SQL_Latin1_General_CP1_CI_AS
@extDescEstado	char	15	15	NULL	10	SQL_Latin1_General_CP1_CI_AS
@extRutCotizante	char	12	12	NULL	11	SQL_Latin1_General_CP1_CI_AS
@extNomCotizante	char	40	40	NULL	12	SQL_Latin1_General_CP1_CI_AS
@extDirPaciente	char	40	40	NULL	13	SQL_Latin1_General_CP1_CI_AS
@extGlosaComuna	char	30	30	NULL	14	SQL_Latin1_General_CP1_CI_AS
@extGlosaCiudad	char	30	30	NULL	15	SQL_Latin1_General_CP1_CI_AS
@extPrevision	char	1	1	NULL	16	SQL_Latin1_General_CP1_CI_AS
@extGlosa	char	40	40	NULL	17	SQL_Latin1_General_CP1_CI_AS
@extPlan	char	15	15	NULL	18	SQL_Latin1_General_CP1_CI_AS
@extDescuentoxPlanilla	char	1	1	NULL	19	SQL_Latin1_General_CP1_CI_AS
@extMontoExcedente	numeric	9	10	0	20	NULL
(20 rows affected)
(return status = 0)
1> 