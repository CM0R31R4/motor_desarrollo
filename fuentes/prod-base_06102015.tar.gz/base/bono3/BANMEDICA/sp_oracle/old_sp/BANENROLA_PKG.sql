
SQL*Plus: Release 11.2.0.3.0 Production on Tue Jul 30 16:33:55 2013

Copyright (c) 1982, 2011, Oracle.  All rights reserved.


Connected to:
Oracle Database 11g Enterprise Edition Release 11.2.0.3.0 - 64bit Production

SQL> SQL> PROCEDURE BANENROLA
 Argument Name			Type			In/Out Default?
 ------------------------------ ----------------------- ------ --------
 SRV_MESSAGE			VARCHAR2		IN/OUT
 IN_EXTCODFINANCIADOR		NUMBER			IN
 IN_EXTRUTENLORAR		VARCHAR2		IN
 IN_EXTRUTBENEFICIARIO		VARCHAR2		IN
 OUT_EXTVALIDO			VARCHAR2		OUT
 OUT_EXTNOMBRECOMP		VARCHAR2		OUT

SQL> Disconnected from Oracle Database 11g Enterprise Edition Release 11.2.0.3.0 - 64bit Production
