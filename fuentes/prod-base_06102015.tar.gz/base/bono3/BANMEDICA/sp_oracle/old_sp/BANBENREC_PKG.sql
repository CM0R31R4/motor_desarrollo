
SQL*Plus: Release 11.2.0.3.0 Production on Tue Jul 30 16:31:43 2013

Copyright (c) 1982, 2011, Oracle.  All rights reserved.


Connected to:
Oracle Database 11g Enterprise Edition Release 11.2.0.3.0 - 64bit Production

SQL> SQL> PROCEDURE BANBENREC
 Argument Name			Type			In/Out Default?
 ------------------------------ ----------------------- ------ --------
 SRV_MESSAGE			VARCHAR2		IN/OUT
 ICODFINANCIADOR		NUMBER			IN
 IRUT_COTIZANTE 		VARCHAR2		IN
 EXTCORRBENEF			VARCHAR2		IN
 EXTRUTBENEFICIARIO		VARCHAR2		IN
 EXTCODRESBEN			VARCHAR2		OUT
 OMENSAJEERROR			VARCHAR2		OUT

SQL> Disconnected from Oracle Database 11g Enterprise Edition Release 11.2.0.3.0 - 64bit Production
