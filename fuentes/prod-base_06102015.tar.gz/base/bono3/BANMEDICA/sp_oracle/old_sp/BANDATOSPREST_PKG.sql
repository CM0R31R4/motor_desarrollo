
SQL*Plus: Release 11.2.0.3.0 Production on Tue Jul 30 16:33:01 2013

Copyright (c) 1982, 2011, Oracle.  All rights reserved.


Connected to:
Oracle Database 11g Enterprise Edition Release 11.2.0.3.0 - 64bit Production

SQL> SQL> PROCEDURE BANDATOSPREST
 Argument Name			Type			In/Out Default?
 ------------------------------ ----------------------- ------ --------
 SRV_MESSAGE			VARCHAR2		OUT
 EXTCODFINANCIADOR		NUMBER			IN
 EXTRUTCONVENIO 		VARCHAR2		IN
 EXTCODIGOSUCUR 		VARCHAR2		IN
 EXTESTCONVENIO 		VARCHAR2		OUT
 EXTNIVEL			NUMBER			OUT
 EXTTIPOPRESTADOR		VARCHAR2		OUT
 EXTCODESPECIALIDADES		VARCHAR2		OUT
 EXTCODPROFESIONES		VARCHAR2		OUT
 EXTANOSANTIGUEDAD		VARCHAR2		OUT

SQL> Disconnected from Oracle Database 11g Enterprise Edition Release 11.2.0.3.0 - 64bit Production
