
SQL*Plus: Release 11.2.0.3.0 Production on Wed Sep 25 11:58:27 2013

Copyright (c) 1982, 2011, Oracle.  All rights reserved.


Connected to:
Oracle Database 10g Enterprise Edition Release 10.2.0.5.0 - 64bit Production
With the Partitioning, OLAP, Data Mining and Real Application Testing options

SQL> SQL> PROCEDURE CONDATOSPREST
 Argument Name			Type			In/Out Default?
 ------------------------------ ----------------------- ------ --------
 SRV_MESSAGE			VARCHAR2		IN/OUT
 IN_NEXTCODFINANCIADOR		NUMBER			IN
 IN_VEXTRUTCONVENIO		VARCHAR2		IN
 IN_VEXTCODIGOSUCUR		VARCHAR2		IN
 OUT_VEXTESTCONVENIO		VARCHAR2		OUT
 OUT_NEXTNIVEL			NUMBER			OUT
 OUT_VEXTTIPOPRESTADOR		VARCHAR2		OUT
 OUT_VEXTCODESPECIALIDADES	VARCHAR2		OUT
 OUT_VEXTCODPROFESIONES 	VARCHAR2		OUT
 OUT_VEXTANOSANTIGUEDAD 	VARCHAR2		OUT

SQL> Disconnected from Oracle Database 10g Enterprise Edition Release 10.2.0.5.0 - 64bit Production
With the Partitioning, OLAP, Data Mining and Real Application Testing options
