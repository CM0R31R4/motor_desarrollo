DELETE FROM cias_seguros WHERE codigo = '19';
INSERT INTO cias_seguros VALUES ('19', 'Consorcio(Trassa)', 'consorcio', 'Certificacion', 'http://10.90.10.8/capacitacioncns/certificacion.asmx', 'sp_respuesta_cia_generica', 'sp_input_cia_generica_cert');
INSERT INTO cias_seguros VALUES ('19', 'Consorcio(Trassa)', 'consorcio', 'Conciliacion', 'http://10.90.10.8/capacitacioncns/conciliacion.asmx', 'sp_respuesta_cia_generica', 'sp_input_cia_generica_cert');
INSERT INTO cias_seguros VALUES ('19', 'Consorcio(Trassa)', 'consorcio', 'Anulacion', 'http://10.90.10.8/capacitacioncns/anulacion.asmx', 'sp_respuesta_cia_generica', 'sp_input_cia_generica_cert');
INSERT INTO cias_seguros VALUES ('19', 'Consorcio(Trassa)', 'consorcio', 'AnulacionBono3', 'http://10.90.10.8/capacitacioncns/anulacion.asmx', 'sp_respuesta_cia_generica', 'sp_input_cia_generica_cert');
INSERT INTO cias_seguros VALUES ('19', 'Consorcio(Trassa)', 'consorcio', 'AnulacionBonoExt', 'http://10.90.10.8/capacitacioncns/anulacion.asmx', 'sp_respuesta_cia_generica', 'sp_input_cia_generica_cert');
INSERT INTO cias_seguros VALUES ('19', 'Consorcio(Trassa)', 'consorcio', 'Confirmacion', 'http://10.90.10.8/capacitacioncns/confirmacion.asmx', 'sp_respuesta_cia_generica', 'sp_input_cia_generica');
INSERT INTO cias_seguros VALUES ('19', 'Consorcio(Trassa)', 'consorcio', 'ConfirmacionBono3', 'http://10.90.10.8/capacitacioncns/confirmacion.asmx', 'sp_respuesta_cia_generica', 'sp_input_cia_generica');
INSERT INTO cias_seguros VALUES ('19', 'Consorcio(Trassa)', 'consorcio', 'ConfirmacionBonoExt', 'http://10.90.10.8/capacitacioncns/confirmacion.asmx', 'sp_respuesta_cia_generica', 'sp_input_cia_generica');

