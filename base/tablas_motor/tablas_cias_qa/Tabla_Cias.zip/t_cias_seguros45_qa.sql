DELETE FROM cias_seguros WHERE codigo = '45';
INSERT INTO cias_seguros VALUES ('45', 'Integramedica(Faraggi)', 'integrafar', 'Anulacion', 'http://10.27.11.6/Anulacion/Anulacion.asmx', 'sp_respuesta_cia_generica', 'sp_input_cia_generica_cert');
INSERT INTO cias_seguros VALUES ('45', 'Integramedica(Faraggi)', 'integrafar', 'AnulacionBono3', 'http://10.27.11.6/Anulacion/Anulacion.asmx', 'sp_respuesta_cia_generica', 'sp_input_cia_generica_cert');
INSERT INTO cias_seguros VALUES ('45', 'Integramedica(Faraggi)', 'integrafar', 'AnulacionBonoExt', 'http://10.27.11.6/Anulacion/Anulacion.asmx', 'sp_respuesta_cia_generica', 'sp_input_cia_generica_cert');
INSERT INTO cias_seguros VALUES ('45', 'Integramedica(Faraggi)', 'integrafar', 'Confirmacion', 'http://10.27.11.6/Confirmacion/Confirmacion.asmx', 'sp_respuesta_cia_generica', 'sp_input_cia_generica');
INSERT INTO cias_seguros VALUES ('45', 'Integramedica(Faraggi)', 'integrafar', 'ConfirmacionBono3', 'http://10.27.11.6/Confirmacion/Confirmacion.asmx', 'sp_respuesta_cia_generica', 'sp_input_cia_generica');
INSERT INTO cias_seguros VALUES ('45', 'Integramedica(Faraggi)', 'integrafar', 'ConfirmacionBonoExt', 'http://10.27.11.6/Confirmacion/Confirmacion.asmx', 'sp_respuesta_cia_generica', 'sp_input_cia_generica');
INSERT INTO cias_seguros VALUES ('45', 'Integramedica(Faraggi)', 'integrafar', 'Certificacion', 'http://10.27.11.6/Certificacion/Certificacion.asmx', 'sp_respuesta_cia_generica', 'sp_input_cia_generica_cert');
INSERT INTO cias_seguros VALUES ('45', 'Integramedica(Faraggi)', 'integrafar', 'Conciliacion', 'http://10.27.11.6/Conciliacion/Conciliacion.asmx', 'sp_respuesta_cia_generica', 'sp_input_cia_generica_cert');

