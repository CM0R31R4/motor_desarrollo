DELETE FROM cias_seguros WHERE codigo = '44';
INSERT INTO cias_seguros VALUES ('44', 'Vida Camara', 'camara', 'Confirmacion', 'http://10.150.73.119/i-med/wsCertificacion.asmx', 'sp_respuesta_cia_generica', 'sp_input_cia_mpro');
INSERT INTO cias_seguros VALUES ('44', 'Vida Camara', 'camara', 'ConfirmacionBono3', 'http://10.150.73.119/i-med/wsCertificacion.asmx', 'sp_respuesta_cia_generica', 'sp_input_cia_mpro');
INSERT INTO cias_seguros VALUES ('44', 'Vida Camara', 'camara', 'ConfirmacionBonoExt', 'http://10.150.73.119/i-med/wsCertificacion.asmx', 'sp_respuesta_cia_generica', 'sp_input_cia_mpro');
INSERT INTO cias_seguros VALUES ('44', 'Vida Camara', 'camara', 'Conciliacion', 'http://10.150.73.119/i-med/wsConciliacion.asmx', 'sp_respuesta_cia_generica', 'sp_input_cia_mpro_cert');
INSERT INTO cias_seguros VALUES ('44', 'Vida Camara', 'camara', 'Anulacion', 'http://10.150.73.119/i-med/wsAnulacion.asmx', 'sp_respuesta_cia_generica', 'sp_input_cia_mpro_cert');
INSERT INTO cias_seguros VALUES ('44', 'Vida Camara', 'camara', 'AnulacionBono3', 'http://10.150.73.119/i-med/wsAnulacion.asmx', 'sp_respuesta_cia_generica', 'sp_input_cia_mpro_cert');
INSERT INTO cias_seguros VALUES ('44', 'Vida Camara', 'camara', 'AnulacionBonoExt', 'http://10.150.73.119/i-med/wsAnulacion.asmx', 'sp_respuesta_cia_generica', 'sp_input_cia_mpro_cert');
INSERT INTO cias_seguros VALUES ('44', 'Vida Camara', 'camara', 'Certificacion', 'http://10.150.73.119/i-med/wsCertificacion.asmx', 'sp_respuesta_cia_generica', 'sp_input_cia_mpro_cert');

