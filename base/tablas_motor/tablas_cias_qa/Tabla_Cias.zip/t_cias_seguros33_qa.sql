DELETE FROM cias_seguros WHERE codigo = '33';
INSERT INTO cias_seguros VALUES ('33', 'CorpVida(Faraggi)', 'far2', 'Confirmacion', 'http://172.28.1.157/Confirmacion/Confirmacion.asmx', 'sp_respuesta_cia_generica', 'sp_input_cia_generica');
INSERT INTO cias_seguros VALUES ('33', 'CorpVida(Faraggi)', 'far2', 'ConfirmacionBono3', 'http://172.28.1.157/Confirmacion/Confirmacion.asmx', 'sp_respuesta_cia_generica', 'sp_input_cia_generica');
INSERT INTO cias_seguros VALUES ('33', 'CorpVida(Faraggi)', 'far2', 'ConfirmacionBonoExt', 'http://172.28.1.157/Confirmacion/Confirmacion.asmx', 'sp_respuesta_cia_generica', 'sp_input_cia_generica');
INSERT INTO cias_seguros VALUES ('33', 'CorpVida(Faraggi)', 'far2', 'Certificacion', 'http://172.28.1.157/Certificacion/Certificacion.asmx', 'sp_respuesta_cia_generica', 'sp_input_cia_generica_cert');
INSERT INTO cias_seguros VALUES ('33', 'CorpVida(Faraggi)', 'far2', 'Conciliacion', 'http://172.28.1.157/Conciliacion/Conciliacion.asmx', 'sp_respuesta_cia_generica', 'sp_input_cia_generica_cert');
INSERT INTO cias_seguros VALUES ('33', 'CorpVida(Faraggi)', 'far2', 'Anulacion', 'http://172.28.1.157/Anulacion/Anulacion.asmx', 'sp_respuesta_cia_generica', 'sp_input_cia_generica_cert');
INSERT INTO cias_seguros VALUES ('33', 'CorpVida(Faraggi)', 'far2', 'AnulacionBono3', 'http://172.28.1.157/Anulacion/Anulacion.asmx', 'sp_respuesta_cia_generica', 'sp_input_cia_generica_cert');
INSERT INTO cias_seguros VALUES ('33', 'CorpVida(Faraggi)', 'far2', 'AnulacionBonoExt', 'http://172.28.1.157/Anulacion/Anulacion.asmx', 'sp_respuesta_cia_generica', 'sp_input_cia_generica_cert');

