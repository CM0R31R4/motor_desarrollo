DELETE FROM cias_seguros WHERE codigo = '38';
INSERT INTO cias_seguros VALUES ('38', 'Chilena Consolidada', 'chicon', 'Confirmacion', 'http://192.168.140.92/VIDA/WebService/Colectivos/wmImed_SrvConfirmacion/Confirmacion.asmx', 'sp_respuesta_cia_generica', 'sp_input_cia_chicon_conf');
INSERT INTO cias_seguros VALUES ('38', 'Chilena Consolidada', 'chicon', 'ConfirmacionBono3', 'http://192.168.140.92/VIDA/WebService/Colectivos/wmImed_SrvConfirmacion/Confirmacion.asmx', 'sp_respuesta_cia_generica', 'sp_input_cia_chicon_conf');
INSERT INTO cias_seguros VALUES ('38', 'Chilena Consolidada', 'chicon', 'ConfirmacionBonoExt', 'http://192.168.140.92/VIDA/WebService/Colectivos/wmImed_SrvConfirmacion/Confirmacion.asmx', 'sp_respuesta_cia_generica', 'sp_input_cia_chicon_conf');
INSERT INTO cias_seguros VALUES ('38', 'Chilena Consolidada', 'chicon', 'Certificacion', 'http://192.168.140.92/VIDA/WebService/Colectivos/wmImed_SrvCertificacion/Certificacion.asmx', 'sp_respuesta_cia_generica', 'sp_input_cia_chicon_cert');
INSERT INTO cias_seguros VALUES ('38', 'Chilena Consolidada', 'chicon', 'Anulacion', 'http://192.168.140.92/VIDA/WebService/Colectivos/wmImed_SrvAnulacion/Anulacion.asmx', 'sp_respuesta_cia_generica', 'sp_input_cia_chicon_anulacion');
INSERT INTO cias_seguros VALUES ('38', 'Chilena Consolidada', 'chicon', 'AnulacionBono3', 'http://192.168.140.92/VIDA/WebService/Colectivos/wmImed_SrvAnulacion/Anulacion.asmx', 'sp_respuesta_cia_generica', 'sp_input_cia_chicon_anulacion');
INSERT INTO cias_seguros VALUES ('38', 'Chilena Consolidada', 'chicon', 'AnulacionBonoExt', 'http://192.168.140.92/VIDA/WebService/Colectivos/wmImed_SrvAnulacion/Anulacion.asmx', 'sp_respuesta_cia_generica', 'sp_input_cia_chicon_anulacion');
INSERT INTO cias_seguros VALUES ('38', 'Chilena Consolidada', 'chicon', 'Conciliacion', 'http://192.168.140.92/VIDA/WebService/Colectivos/wmImed_SrvConciliacion/Conciliacion.asmx', 'sp_respuesta_cia_generica', 'sp_input_cia_chicon_concilia');

