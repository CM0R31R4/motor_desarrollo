DELETE FROM cias_seguros WHERE codigo = '28';
INSERT INTO cias_seguros VALUES ('28', 'Bice Vida', 'bice', 'Confirmacion', 'http://192.168.122.10:7777/IMED-WebServices/WsConfirmacionSoap', 'sp_respuesta_cia_generica', 'sp_input_cia_generica');
INSERT INTO cias_seguros VALUES ('28', 'Bice Vida', 'bice', 'ConfirmacionBono3', 'http://192.168.122.10:7777/IMED-WebServices/WsConfirmacionSoap', 'sp_respuesta_cia_generica', 'sp_input_cia_generica');
INSERT INTO cias_seguros VALUES ('28', 'Bice Vida', 'bice', 'ConfirmacionBonoExt', 'http://192.168.122.10:7777/IMED-WebServices/WsConfirmacionSoap', 'sp_respuesta_cia_generica', 'sp_input_cia_generica');
INSERT INTO cias_seguros VALUES ('28', 'Bice Vida', 'bice', 'Conciliacion', 'http://192.168.122.10:7777/IMED-WebServices/WsConciliacionSoap', 'sp_respuesta_cia_generica', 'sp_input_cia_chicon_concilia');
INSERT INTO cias_seguros VALUES ('28', 'Bice Vida', 'bice', 'Certificacion', 'http://192.168.122.10:7777/IMED-WebServices/WsCertificacionSoap', 'sp_respuesta_cia_generica', 'sp_input_cia_chicon_cert');
INSERT INTO cias_seguros VALUES ('28', 'Bice Vida', 'bice', 'Anulacion', 'http://192.168.122.10:7777/IMED-WebServices/WsAnulacionSoap', 'sp_respuesta_cia_generica', 'sp_input_cia_chicon_anulacion');
INSERT INTO cias_seguros VALUES ('28', 'Bice Vida', 'bice', 'AnulacionBono3', 'http://192.168.122.10:7777/IMED-WebServices/WsAnulacionSoap', 'sp_respuesta_cia_generica', 'sp_input_cia_chicon_anulacion');
INSERT INTO cias_seguros VALUES ('28', 'Bice Vida', 'bice', 'AnulacionBonoExt', 'http://192.168.122.10:7777/IMED-WebServices/WsAnulacionSoap', 'sp_respuesta_cia_generica', 'sp_input_cia_chicon_anulacion');

