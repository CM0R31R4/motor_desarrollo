DELETE FROM cias_seguros WHERE codigo = '14';
INSERT INTO cias_seguros VALUES ('14', 'Sura(Mpro)', 'ing', 'Conciliacion', 'http://10.90.10.8/capacitacioning/conciliacion.asmx', 'sp_respuesta_cia_generica', 'sp_input_cia_generica_cert');
INSERT INTO cias_seguros VALUES ('14', 'Sura(Mpro)', 'ing', 'ConfirmacionBono3', 'http://10.90.10.8/capacitacioning/confirmacion.asmx', 'sp_respuesta_cia_generica', 'sp_input_cia_generica');
INSERT INTO cias_seguros VALUES ('14', 'Sura(Mpro)', 'ing', 'ConfirmacionBonoExt', 'http://10.90.10.8/capacitacioning/confirmacion.asmx', 'sp_respuesta_cia_generica', 'sp_input_cia_generica');
INSERT INTO cias_seguros VALUES ('14', 'Sura(Mpro)', 'ing', 'Confirmacion', 'http://10.90.10.8/capacitacioning/confirmacion.asmx', 'sp_respuesta_cia_generica', 'sp_input_cia_generica');
INSERT INTO cias_seguros VALUES ('14', 'Sura(Mpro)', 'ing', 'Certificacion', 'http://10.90.10.8/capacitacioning/certificacion.asmx', 'sp_respuesta_cia_generica', 'sp_input_cia_generica_cert');
INSERT INTO cias_seguros VALUES ('14', 'Sura(Mpro)', 'ing', 'Anulacion', 'http://10.90.10.8/capacitacioning/anulacion.asmx', 'sp_respuesta_cia_generica', 'sp_input_cia_generica_cert');
INSERT INTO cias_seguros VALUES ('14', 'Sura(Mpro)', 'ing', 'AnulacionBono3', 'http://10.90.10.8/capacitacioning/anulacion.asmx', 'sp_respuesta_cia_generica', 'sp_input_cia_generica_cert');
INSERT INTO cias_seguros VALUES ('14', 'Sura(Mpro)', 'ing', 'AnulacionBonoExt', 'http://10.90.10.8/capacitacioning/anulacion.asmx', 'sp_respuesta_cia_generica', 'sp_input_cia_generica_cert');

